package co.gov.ugpp.parafiscales.servicios.liquidador.srvaplliquidacion.gestorprograma;

public interface RuntimeScript
{
   public Double ejecutarScript(String script) throws Exception;
}
