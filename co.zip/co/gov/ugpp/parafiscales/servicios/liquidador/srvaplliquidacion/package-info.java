@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ugpp.gov.co/Liquidador/SrvAplLiquidador")
package co.gov.ugpp.parafiscales.servicios.liquidador.srvaplliquidacion;
