package co.gov.ugpp.parafiscales.servicios.liquidador.srvaplliquidacion.gestorprograma;


public class EjecutorRegla extends Thread implements java.io.Serializable {

    private static final long serialVersionUID = -7584387284078848566L;

}
